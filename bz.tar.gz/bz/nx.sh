#!/usr/bin/env bash
# bz v100.60 - sample nexa launcher
#
# nexa

cd "$(dirname "$0")" || exit 1

# No pool: this runs the built-in benchmark so you can verify the miner
# works. To mine nexa to a pool, replace the line below with:
#   ./b --config c.txt -a nexa -p stratum+tcp://YOUR_POOL:PORT -w YOUR_WALLET_HERE

./b --config c.txt --bench -a nexa

# pwn
