#!/usr/bin/env bash
# bz v100.60 - sample WORKER launcher (c29)
#
# Mines c29 THROUGH the bz running start_proxy_c29.sh: no pool
# connection of its own. It still pays its OWN dev fee - the proxy carries
# that connection too, so this rig needs no route to the internet, and the
# proxy signals when the farm's slice is due so the whole farm pays in one
# window. The real pool is listed second, so if the proxy goes away this rig
# fails over to it and mines it directly.
#
# EDIT the proxy's address (PROXY-IP) and give each rig its own --worker name:
# that name is what the proxy's tables show for it.

cd "$(dirname "$0")" || exit 1

./b --config c.txt -a c29 -p bzproxy://PROXY-IP:4100 -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass x --worker rig1


# pwn
