#!/usr/bin/env bash
# bz v100.60 - sample TWO-ALGORITHM launcher
#
# pearl on the GPUs and randomx on the CPU, at the same time, in one miner.
#
# -a takes a list. The first algorithm is 1 and the second is 2, and every
# pool flag carries that number: --p1/--w1 are pearl's, --p2/--w2 are
# randomx's. A second --p1 is a failover pool for pearl.
#
# Nothing says which device mines what, because nothing needs to: randomx
# cannot use a GPU, so pearl takes every card, and the CPU is shared - each
# algorithm gets half of the rig's CPU threads, on separate processors. To
# change that, add any of these to the line:
#   --cpu_threads1 4 --cpu_threads2 24   give each algorithm its own count
#   --devices1 gpu                       keep pearl off the CPU entirely
#   --cpu_affinity2 8-31                 name randomx's processors outright
#   --cpu_threads 28                     the rig-wide budget the split comes from
#
# EDIT BOTH WALLETS BELOW before running - they are placeholders, not real
# addresses, and the pools will reject shares sent to them.

cd "$(dirname "$0")" || exit 1

./b --config c.txt -a pearl,randomx --p1 stratum+tcp://us.pearl.herominers.com:1200 --w1 prl1YOUR_PEARL_WALLET_HERE --pass1 x --worker1 rig1 --p2 stratum+ssl://gulf.moneroocean.stream:20128 --w2 YOUR_MONERO_WALLET --pass2 x --worker2 rig1

# Other pools for either algorithm are listed, one per line, in start_pearl.sh
# and start_randomx.sh; carry one over as another --p1 or --p2.
# Both algorithms share the dashboard at http://127.0.0.1:4014/.

# pwn
