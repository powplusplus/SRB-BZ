#!/usr/bin/env bash
# bz v100.60 - sample quantus launcher
#
# Quantus Poseidon2 over the Goldilocks field, on NVIDIA, AMD and Intel
# Battlemage GPUs and the CPU. Also mines SOLO - point -p at your own node's
# authenticated QUIC miner port instead of a pool. Wallet addresses start
# with 'q' and are 49 characters long.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# The first line is live. To use a different pool, comment it out
# and uncomment one below.

./b --config c.txt -a quantus -p stratum+tcp://us-east.lproute.com:5660 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512

#   LuckyPool (US west)
# ./b --config c.txt -a quantus -p stratum+tcp://us-west.lproute.com:5660 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512
#   LuckyPool (Europe)
# ./b --config c.txt -a quantus -p stratum+tcp://eu.lproute.com:5660 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512
#   LuckyPool (Singapore)
# ./b --config c.txt -a quantus -p stratum+tcp://sg.lproute.com:5660 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512
#   Kryptex - takes a Kryptex account name or a wallet; bz sends
#   Kryptex's wallet/worker form rather than wallet.worker
# ./b --config c.txt -a quantus -p stratum+tcp://qtc.kryptex.network:7049 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512
#   quanpool (Europe, main server) - PPLNS, 1% fee. This pool speaks QUIC
#   over UDP rather than stratum, so open outbound UDP to the port. The pin
#   below is quanpool's published certificate fingerprint and is the same
#   for every region.
# ./b --config c.txt -a quantus -p quic://eu.quanpool.com:9834 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512 --quantus.tls-pin 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6
#   quanpool (North America, Montreal) - PPLNS
# ./b --config c.txt -a quantus -p quic://us.quanpool.com:9834 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512 --quantus.tls-pin 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6
#   quanpool (Asia, Singapore) - PPLNS
# ./b --config c.txt -a quantus -p quic://asia.quanpool.com:9834 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512 --quantus.tls-pin 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6
#   quanpool SOLO - the same pool and the same address; port 9844 instead of
#   9834 is the whole difference. You keep a full block when you find one,
#   and earn nothing in between.
# ./b --config c.txt -a quantus -p quic://eu.quanpool.com:9844 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512 --quantus.tls-pin 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6
#   SOLO against your own node (quantus-node --validator --miner-listen-port
#   9833). The node picks the reward account, so the wallet on this line is
#   ignored. Both files below live in the node's chain data directory.
# ./b --config c.txt -a quantus -p quic://127.0.0.1:9833 -w qYOUR_QUANTUS_ADDRESS_HERE --pass x --worker rig1 --intensity 512 --quantus.auth-token-file /path/to/node-data/chains/dev/miner-auth-token --quantus.tls-pin-file /path/to/node-data/chains/dev/miner-tls-cert-sha256

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
