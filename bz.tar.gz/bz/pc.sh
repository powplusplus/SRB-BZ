#!/usr/bin/env bash
# bz v100.60 - Pearl + C29 dual mining on MoneroOcean
# Run beside the matching bz binary, as in the release archive.
# Replace BOTH wallet placeholders with your XMR payout address.
# The same XMR address can be used for both; do not use a Pearl/Tari wallet.
# Worker names belong before ~pearl / ~c29 in the passwords.
# Compatible NVIDIA or AMD GPUs select the shared route automatically after calibration.
# Below 100% combined throughput, the GPU returns to ordinary assignment.

cd "$(dirname "$0")" || exit 1

./b --config c.txt -a pearl,c29 --nvidia 1 --amd 1 --cpu 0 --p1 stratum+tcp://gulf.moneroocean.stream:10128 --w1 4YOUR_MONERO_WALLET_HERE --worker1 "" --pass1 rig1-pearl~pearl --p2 stratum+tcp://gulf.moneroocean.stream:10128 --w2 4YOUR_MONERO_WALLET_HERE --worker2 "" --pass2 rig1-c29~c29

# pwn
