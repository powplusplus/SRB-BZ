#!/usr/bin/env bash
# bz v100.60 - sample kawpow launcher
#
# Ravencoin KawPow on NVIDIA CUDA, AMD OpenCL, and Apple Metal GPUs. NVIDIA
# specializes the three-block random program through the driver's PTX JIT,
# with precompiled cubins as its fallback; AMD uses offline-native gfx code
# objects; Apple Silicon uses a portable offline metallib. No CUDA toolkit,
# NVRTC, ROCm compiler, OpenCL C source, Metal source, or external GPU
# compiler is required on the mining rig; the AMD and Apple paths do no
# runtime compilation. Answers to `kawpow` and to each KawPow coin by name
# (rvn, xna, neoxa, meowcoin, clore), which selects the chain you mine. A
# wallet address for the coin being mined. The worker name is a separate
# --worker argument, not a suffix on the address.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# One line per coin. The FIRST is live; to mine a different coin,
# comment this one out and uncomment that one.
#
# -a picks the chain, so it changes with the pool - and so does the
# wallet, since every coin has its own address format.
# Coins: `rvn`, `xna`, `neoxa`, `meowcoin`, `clore`, `kawpow`.

# --- Ravencoin (rvn)
#   WoolyPooly US
./b --config c.txt -a rvn -p stratum+ssl://pool.us.woolypooly.com:55555 -w RYOUR_RAVENCOIN_WALLET_HERE --pass x --worker rig1
#   2Miners
# ./b --config c.txt -a rvn -p stratum+ssl://rvn.2miners.com:16060 -w RYOUR_RAVENCOIN_WALLET_HERE --pass x --worker rig1

# --- Neurai (xna)
#   rplant - Neurai is on the ASIA host only
# ./b --config c.txt -a xna -p stratum+ssl://stratum-asia.rplant.xyz:17029 -w NYOUR_NEURAI_WALLET_HERE --pass x --worker rig1

# --- Neoxa (neoxa)
#   rplant EU
# ./b --config c.txt -a neoxa -p stratum+ssl://stratum-eu.rplant.xyz:17069 -w GYOUR_NEOXA_WALLET_HERE --pass x --worker rig1

# --- Meowcoin (meowcoin)
#   rplant EU
# ./b --config c.txt -a meowcoin -p stratum+ssl://stratum-eu.rplant.xyz:17120 -w MYOUR_MEOWCOIN_WALLET_HERE --pass x --worker rig1

# --- Clore (clore)
#   rplant EU
# ./b --config c.txt -a clore -p stratum+ssl://stratum-eu.rplant.xyz:17063 -w AYOUR_CLORE_WALLET_HERE --pass x --worker rig1
#   rplant Asia
# ./b --config c.txt -a clore -p stratum+ssl://stratum-asia.rplant.xyz:17063 -w AYOUR_CLORE_WALLET_HERE --pass x --worker rig1

# --- MoneroOcean (any KawPow coin, paid in XMR) (kawpow)
# ./b --config c.txt -a kawpow -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass rig1~kawpow --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
