#!/usr/bin/env bash
# bz v100.60 - sample xelis launcher
#
# XELIS xelhash. Wallet addresses start with 'xel:'.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# The first line is live. To use a different pool, comment it out
# and uncomment one below.

./b --config c.txt -a xelis -p stratum+ssl://us.vipor.net:5177 -w xel:YOUR_XELIS_WALLET_HERE --pass x --worker rig1

#   HeroMiners (TLS)
# ./b --config c.txt -a xelis -p stratum+ssl://us.xelis.herominers.com:1225 -w xel:YOUR_XELIS_WALLET_HERE --pass x --worker rig1
#   SOLO, to your own node
# ./b --config c.txt -a xelis -p ws://127.0.0.1:8080 -w xel:YOUR_XELIS_WALLET_HERE --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
