#!/usr/bin/env bash
# bz v100.60 - sample ergo launcher
#
# Ergo Autolykos v2. GPU only, and memory-hard: it builds a table of N
# 32-byte elements (about 2 GB) in VRAM, so a card needs the room for it. N
# grows with block height, and the table is rebuilt when it changes. Wallet
# addresses start with '9'.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# The first line is live. To use a different pool, comment it out
# and uncomment one below.

./b --config c.txt -a ergo -p stratum+tcp://pool.us.woolypooly.com:3100 -w 9YOUR_ERGO_WALLET_HERE --pass x --worker rig1

#   MoneroOcean - mines Autolykos2, pays in XMR (wallet is an XMR address)
# ./b --config c.txt -a ergo -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass rig1~autolykos2 --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
