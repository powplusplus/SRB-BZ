#!/usr/bin/env bash
# bz v100.60 - sample sha256d launcher
#
# The open-source SDK example: a full algorithm plugin (CPU+GPU, pool
# stratum, bench job source). Copy plugins/public/sha256d as a template for
# your own.

cd "$(dirname "$0")" || exit 1

# No pool: this runs the built-in benchmark so you can verify the miner
# works. To mine sha256d to a pool, replace the line below with:
#   ./b --config c.txt -a sha256d -p stratum+tcp://YOUR_POOL:PORT -w YOUR_WALLET_HERE

./b --config c.txt --bench -a sha256d

# pwn
