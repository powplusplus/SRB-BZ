#!/usr/bin/env bash
# bz v100.60 - sample warthog launcher
#
# Warthog janushash - the GPU filters sha256t and the CPU runs verushash, on
# the same nonces. Needs BOTH a GPU and the CPU; one without the other finds
# nothing. Wallet addresses are 48 hex characters.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# The first line is live. To use a different pool, comment it out
# and uncomment one below.

./b --config c.txt -a warthog -p stratum+ssl://us.vipor.net:5120 -w YOUR_WARTHOG_WALLET_HERE --pass x --worker rig1

#   WoolyPooly
# ./b --config c.txt -a warthog -p stratum+tcp://pool.us.woolypooly.com:3140 -w YOUR_WARTHOG_WALLET_HERE --pass x --worker rig1
#   acc-pool
# ./b --config c.txt -a warthog -p stratum+tcp://acc-pool.pw:12000 -w YOUR_WARTHOG_WALLET_HERE --pass x --worker rig1
#   SOLO, to your own node over RPC
# ./b --config c.txt -a warthog -p http://127.0.0.1:3000 -w YOUR_WARTHOG_WALLET_HERE --pass x --worker rig1
#   SOLO, to your own node over stratum - run the node with --stratum
#   0.0.0.0:3456
# ./b --config c.txt -a warthog -p stratum+tcp://127.0.0.1:3456 -w YOUR_WARTHOG_WALLET_HERE --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
