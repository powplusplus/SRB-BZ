#!/usr/bin/env bash
# bz v100.60 - sample PROXY launcher (c29)
#
# This machine holds the ONE pool connection for c29 and hands the work to
# every other bz started with start_worker_c29.sh (pointed at this
# machine's address). Their shares go to the pool through here, each rig's
# own dev fee is carried through here too (the rigs need no internet of their
# own), and each rig is a light-blue row in this miner's tables and dashboard
# (http://127.0.0.1:4014/). The port is TLS.
#
# It mines on this machine's own devices as well. For a box that should only
# proxy, add:   --devices none --cpu 0
# On anything but a private LAN, set a password the rigs must give:
#               --proxy_pass <secret>     (and --pass <secret> on each rig)
#
# EDIT THE WALLET BELOW before running - it is a placeholder.

cd "$(dirname "$0")" || exit 1

./b --config c.txt -a c29 -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass x --worker proxy --proxy_port 4100


# pwn
