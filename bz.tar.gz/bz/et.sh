#!/usr/bin/env bash
# bz v100.60 - sample ethash launcher
#
# Ethereum Classic Ethash and etchash on NVIDIA CUDA GPUs, from precompiled
# cubins - no CUDA toolkit, NVRTC or GPU compiler is needed on the rig.
# Answers to `ethash`/`ethw`/`ethereumpow` for ETHW and to `etchash`/`etc`
# for Ethereum Classic; the name selects the DAG epoch schedule, so it must
# match the chain the pool is serving. The chain's 0x address for that
# chain. The worker name is a separate --worker argument, not a suffix on
# the address.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# One line per coin. The FIRST is live; to mine a different coin,
# comment this one out and uncomment that one.
#
# -a picks the chain, so it changes with the pool - and so does the
# wallet, since every coin has its own address format.
# Coins: `etchash`, `ethash`.

# --- Ethereum Classic (etchash)
#   2Miners
./b --config c.txt -a etchash -p stratum+tcp://etc.2miners.com:1010 -w 0xYOUR_ETC_WALLET_HERE --pass x --worker rig1
#   2Miners, TLS
# ./b --config c.txt -a etchash -p stratum+ssl://etc.2miners.com:11010 -w 0xYOUR_ETC_WALLET_HERE --pass x --worker rig1

# --- EthereumPoW (ethash) - f2pool signs in with your f2pool ACCOUNT NAME, not a wallet address - no wallet-addressed ETHW pool answered on 2026-08-31
#   F2Pool
# ./b --config c.txt -a ethash -p stratum+tcp://ethw.f2pool.com:6688 -w YOUR_F2POOL_ACCOUNT_NAME --pass x --worker rig1

# --- MoneroOcean (etchash, paid in XMR) (etchash)
# ./b --config c.txt -a etchash -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass rig1~etchash --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
