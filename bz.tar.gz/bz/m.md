# Mining on the AMD BC-250

The BC-250 is a PS5-derived "Oberon" APU on an ASRock mining board: a 6-core Zen 2
CPU and a gfx1013 "Cyan Skillfish" GPU sharing one 16 GB pool of GDDR6. They turn up
cheap on the second-hand market and they are genuinely good at some of what bzminer
does — but the board ships deliberately cut down in three ways, and a stock one
leaves a lot on the table.

Everything here was measured on a BC-250, not inferred. Where a number is missing
or a claim is untested, it says so.

---

## The short version

```bash
sudo ./bzminer -a warthog -p <pool> -w <wallet>
```

Run it as root and bzminer switches the two disabled CPU cores on by itself (they
appear after one reboot) and leaves everything else as it found it: an overclock from
your mining OS dashboard or a governor stays in charge of the GPU clock, and the 16
disabled compute units stay off. The two bigger gains are a flag each, because each
is a trade you should make knowingly:

```bash
sudo ./bzminer -a pearl -p <pool> -w <wallet> --bc250-cu                  # all 40 compute units, live
sudo ./bzminer -a warthog -p <pool> -w <wallet> --bc250-gpu-clock 1800    # pin the shader clock
```

Both go in `config.txt` too: `"bc250": {"cu": true, "gpu_mhz": 1800}`.

If you want to stay fully stock: `--no-bc250-gpu --no-bc250-cpu`. The option table is
[below](#what-the-board-ships-locked-and-what-bzminer-does-about-it).

---

## Run bzminer as root, or it will not see the GPU at all

This catches everyone. `/dev/dri/renderD128` is owned by the `render` group, and on
most images the login user is in `video` but **not** `render`. Without it the AMD
OpenCL runtime enumerates **zero devices** and the miner quietly falls back to
CPU-only — no error, just a missing GPU.

```bash
sudo usermod -aG render,video $USER   # then log out and back in
```

or run bzminer under `sudo`. bzminer says so explicitly when it hits this, rather
than leaving you to work it out.

Running as root is also what lets bzminer apply the unlocks below; unprivileged, it
tells you what it would have done.

---

## What the board ships locked, and what bzminer does about it

| what the board limits | as it ships | what the hardware can do | what bzminer does about it |
|---|---|---|---|
| GPU shader clock | 1500 MHz | 500 to 2000 MHz | **opt-in** — `--bc250-gpu-clock <mhz>`; otherwise the OS's overclock or governor is left alone |
| CPU cores | 6 of 8 usable | all 8 | **automatic** — takes one reboot |
| GPU compute units | 24 of 40 enabled | all 40 | **opt-in** — `--bc250-cu`, live, no reboot or driver reload |

All three are volatile. **A cold power cycle puts the board back to factory** — which
is your undo button if anything misbehaves, and also means bzminer applies whatever
you asked for again the next time it starts.

Every option, with its `config.txt` spelling (a `bc250` block):

| command line | `config.txt` | what it does |
|---|---|---|
| `--bc250-gpu-clock <mhz>` | `"gpu_mhz": 1800` | pin the shader clock, 500-2000 MHz, below stock included; released on exit |
| `--bc250-gpu-mv <mv>` | `"gpu_mv": 850` | the voltage for the pinned clock, 700-1000 mV, instead of what the curve gives |
| `--no-bc250-gpu` | `"gpu": false` | release any forced clock, yours or the OS's, and leave the stock 1500 |
| `--no-bc250-cpu` | `"cpu": false` | leave the two disabled CPU cores off |
| `--bc250-cu` | `"cu": true` | enable all 40 compute units, live |
| `--unlock-bc250-cu` / `--restore-bc250-cu` | — | the same CU change as a one-shot command that then exits |

**If you run mmpOS, HiveOS or a governor:** they set the GPU clock through the same
SMU mailbox bzminer uses. You do not need to tell bzminer anything — without
`--bc250-gpu-clock` it leaves the clock alone, so the overclock in your dashboard
applies as set. Pin the clock in one place only, either the OS profile or bzminer. A
running governor (`oberon-governor` and friends) makes bzminer stand down from the
SMU completely, even if you pass a clock, because two programs writing one mailbox
is how the board's telemetry gets wedged; stop the governor if you want bzminer to
pin the clock. bzminer bundles everything it needs for this - no governor, driver
patch or script has to be installed for any of the options above.

### GPU clock — opt-in

The shader array is pinned at 1500 MHz until something tells the SMU otherwise.
By default bzminer leaves it to whatever the OS set: an mmpOS or HiveOS overclock
from the dashboard, or a governor, goes through the same SMU mailbox, and bzminer
forcing its own clock on top of it replaced a user's deliberate 1200 MHz with 2000
on every start. The only clock it releases on its own is one a previous bzminer
run left forced (a crash or a kill skips the exit-time release; the forcing run
leaves a marker in `/var/tmp` so the next one knows the leftover is its own).

`--bc250-gpu-clock <mhz>` pins a clock, with the voltage scaled to match, and
releases it on exit. Anything from 500 to 2000 MHz is honoured, below the stock
1500 included: that is how a packed chassis buys heat and power back.

Measured with warthog, voltage tracking the clock:

| clock | janus | sha | GPU power | temp | janus/W |
|---|---|---|---|---|---|
| off (stock 1500) | 263.88 MH/s | 567.21 MH/s | 105 W | 63 °C | **2.51** |
| **1800 (default)** | **281.69 MH/s** | 675.91 MH/s | 116 W | 80 °C | 2.43 |
| 2000 | 291.25 MH/s | 749.10 MH/s | 155 W | 88 °C | 1.88 |

1800 MHz is +6.8% for +10% power, holding efficiency within 3% of stock. 2000 MHz
is available (`--bc250-gpu-clock 2000`) and buys another 3.4% — but for a 34% power
jump and a quarter of the efficiency, which loses money anywhere electricity is not
free. It also runs 88 °C on an open bench, before you rack four of them together.

**xelis gains nothing from this.** It is bound by memory bandwidth, and the memory
clock is not what moves — 4.23 kH/s at 1500 MHz and 4.23 kH/s at 2000 MHz, for an
extra 50 W. If you mine xelis on this board, pass `--no-bc250-gpu`.

```bash
                            (no flag) leave the clock to the OS's overclock or governor
--bc250-gpu-clock 1800      the measured sweet spot: +6.8% janus for +10% power
--bc250-gpu-clock 2000      rate over efficiency
--bc250-gpu-clock 1650      a cooler compromise for a packed chassis
--bc250-gpu-clock 1200      below stock: less heat and power, for a chassis that cannot shed it
--no-bc250-gpu              release any forced clock, ours or not, and leave the stock 1500
```

### CPU cores — on by default, needs one reboot

Six of the eight Zen 2 cores are enabled. The other two are not fused off: the core
presence mask reads `0x77` on essentially every board — core 3 of each CCX,
symmetrically — which is a product decision, not a harvest.

bzminer sets the mask to all 8 at startup. **The cores appear on the next boot**,
because the mask is read when the OS enumerates CPUs, so the run that sets it cannot
use them. A warm reboot is enough. Worth roughly a third more verus, and verus
carries about 0.53 of warthog's janus score.

```bash
--no-bc250-cpu              leave it at 6 cores
```

### Compute units — opt-in, live, no reboot

The die has 40 CUs and 16 are switched off. They are not fused: the shader-array config
and per-array WGP masks say 24 and both are writable while the GPU runs. With
`--bc250-cu` (or `"cu": true` in the config) bzminer writes them at startup, as root,
and the extra CUs are in use immediately. No reboot, no amdgpu reload, no patched
driver, nothing else to install.

Measured on a BC-250 (kernel 6.1.77-mmp, AMD amdgpu 6.1.10), Pearl search kernel,
24 CUs then 40 CUs in the same session, same accepted-tile set before and after:
**2.105 → 3.451 T MAC/s (×1.64)**. `sudo ./bzminer --unlock-bc250-cu` /
`--restore-bc250-cu` do the same as a one-shot and exit.

It is opt-in, not automatic, because the 16 CUs were switched off at the factory and
on some boards they are defective. bzminer checks that every register took the new
layout; it cannot check that each CU computes correctly, and a bad one faults only
under load. Switching them on is your call, and a new board deserves a stress test
before you trust its shares.

How it stays safe: the writes need a different shader array selected for each one, which
is a shared selector the driver changes constantly under a kernel lock that userspace
cannot take. bzminer never touches the BAR. It uses amdgpu's debugfs register files, where
the *driver* does the selection holding its own lock: `amdgpu_regs2` on kernels that have
it (mainline 6.2+), and the older `amdgpu_regs`, whose file offset carries the selection,
on the 6.1.x images that do not. It only writes a register after reading back the
documented stock value from it.

Things to know:

* **Reloading amdgpu is not a way to do this.** On the MMP image, reloading the module after
  the register writes failed `sdma0 ring test` (-110), and even the stock module failed the
  same way until a reboot. Nothing here needs it, and the driver keeps *reporting* 24 CUs
  (OpenCL: 12 compute units, which count WGPs) because it caches that at init - the
  hardware dispatches to all 40 regardless.
* **The 16 CUs may be off for a reason.** On most boards they are fine; on some they are
  genuinely defective and fault only under load. Nothing can tell you which yours is —
  stress-test before trusting it. Expect about +30 W.
* **Heat.** 40 CUs at 2000 MHz measured 95-100 C on the stock cooler (173 W) with Pearl;
  1900 MHz was 92 C. Pearl hashrate at 40 CUs: 1500 MHz 3.08 TH/s (58 W), 1700 3.57,
  1800 3.68, 1900 3.88, 2000 3.95. A throttling board is slower than a cooler clock.
* A boot-time alternative exists for kernels where even the debugfs files are missing:
  the community patch (`docs/benchmarks/pearl-bc250-20260930/bc250-40cu-dkms615.patch`
  with `mkcu40.sh`) applies the same registers at driver init, but it has to be built into
  the image's initramfs, and it is no longer needed on kernels like the MMP one.

`sudo ./bzminer --restore-bc250-cu` puts the factory 24 back, as does a power cycle.

Do not run 40 CUs at 2000 MHz on the stock cooler. It throttles, and a throttling
board is slower than either change on its own.

---

## What to mine on it

**warthog is the one this board is good at.** It wants a GPU doing sha256t and a CPU
doing verushash at the same time, which is exactly what an APU is. Stock it scores
about 264 MH/s janus; pinned at 1800 MHz, about 282.

**xelis runs well but ignores every knob.** ~4.2 kH/s, bound by memory bandwidth
rather than shader count or clock. bzminer already sizes its launch for the board's
real 24 CUs (OpenCL reports 12, because it counts WGPs, not CUs — sizing from that
number directly would leave the card a third empty).

**pearl, ergo, sha256d and verus all work.** verus is CPU-only and benefits from the
core unlock; the rest are GPU and benefit from the clock.

---

## The unified memory, since people ask

The 16 GB of GDDR6 is split by firmware into 8 GiB of "VRAM" and ~7.5 GiB of system
RAM, but it is one pool on one controller with no PCIe between the halves. Measured:

| | |
|---|---|
| GPU reading VRAM | 426 GB/s |
| GPU reading *host* memory | **419 GB/s** — 1.6% slower |
| Mapping 256 MB to the CPU | 0.1 ms (a real zero-copy map) |
| SVM | coarse **and fine-grain** buffers |

So GPU→CPU hand-off is effectively free here. `clinfo` reporting
`Unified memory: 0` is a misleading legacy flag; ignore it.

This matters less for mining than it looks. warthog's GPU→CPU candidate path already
has roughly 150× more headroom than it uses, so making it zero-copy would optimise
something that is not the bottleneck — the constraint is the 6-core CPU's verus rate.
The unified memory is why the *CPU* unlock is worth more here than the transfer path.

---

## Troubleshooting

**No GPU in the device list.** You are not in the `render` group. See above.

**"a GPU governor is already running".** A community governor owns the SMU mailbox,
so bzminer stands down rather than fight it for the clock. That is fine — you already
have the clock you asked for. Stop the governor if you want bzminer to manage it.

**Telemetry died: no temps, no power, clocks stuck.** Something wedged the SMU
mailbox — the driver reports `SMU: I'm not done with your previous command` in
`dmesg`. The GPU keeps mining perfectly; only monitoring is dead. A cold power cycle
clears it. bzminer is careful not to cause this (it never leaves the mailbox's
response register cleared), but other tools poking the SMU at the same time can.

**The clock did not go up.** bzminer does not raise it on its own: pass
`--bc250-gpu-clock <mhz>` or set it in your mining OS dashboard. If you did, check
you are root, that no governor is running, and that `--no-bc250-gpu` is not set in
your config. bzminer prints what it applied at startup. Note the reported clock is
the *current* one — an idle GPU sits below the forced target and reaches it under
load.

**The clock changed to something I did not set.** A previous bzminer run that was
killed or crashed left its pinned clock behind, and the next start released it to
stock; that is the only clock a start without `--bc250-gpu-clock` ever changes.
Overclocks set in mmpOS or HiveOS are left exactly as they are.

**Only 24 CUs.** That is the default. `--bc250-cu` enables all 40, as root; see
above for why it is not automatic.

**It says the GPU is at 1800 MHz but xelis is no faster.** Expected. xelis is memory
bound; see above.

---

## Pearl on the BC-250 (2026-09-30)

gfx1013 has no `v_dot4`, so the old image did the int8 products as `v_mul_i32_i24_sdwa` +
`v_add3_u32`: 1.5 VALU per MAC, 95% of what the part can issue. Microbenchmark
(`docs/benchmarks/pearl-bc250-20260930/micro.py`): every VALU op, including
`v_mad_i32_i16`, `v_mad_i32_i24` and `v_pk_mad_i16`, issues at the same full rate; only
`v_mul_lo_u32` is quarter rate. `PEARL_MAD16=1` writes the staged operands to LDS as
sign-extended int16 and does one `v_mad_i32_i16` per MAC (op_sel picks the half), 1.0 VALU/MAC.
Exact, and it cannot go lower without packing two products per lane, which overflows 16 bits
for int8 operands (worst-case sums of 4 products exceed 32767, and with the products'
heavy tails it would happen constantly).

| config (kernel harness, interleaved) | old image | PEARL_MAD16 |
|---|---:|---:|
| 24 CU, ~1.5 GHz | 1.417 T MAC/s | 2.104 (+48.5%) |
| 40 CU, ~1.5 GHz | 2.333 | 3.447 (+47.7%) |

In-miner, 40 CU + MAD16, fixed-difficulty benchmark at 1e12 (pool-measured TH/s, board W, C):
1500 MHz 3.08 / 58 W / 62 C; 1700 3.57 / 149 W / 85 C; 1800 3.68 / 160 W / 92 C;
1900 3.88 / 165 W / 92 C; 2000 3.95 / 173 W / 100 C. 1500 MHz at stock voltage is by far the
most efficient point. The `--benchmark` rate at low difficulty is share-handling bound and
says nothing about the kernel.

### Voltage (Pearl, 40 CUs, 2000 MHz, 100 s legs, zero rejects)

| forced mV | TH/s | power | temp |
|---:|---:|---:|---:|
| 1000 (old default) | 4.59 | 174 W | 98 °C |
| 950 | 4.57 | 155 W | 92 °C |
| 900 (new default at 2000 MHz) | 4.57 | 138 W | 84 °C |
| 850 | 4.56 | 125 W | 78 °C |
| 800 | the board hard-hung and needed a power cycle | | |

1900 MHz held at 900 and 850 mV, 1800 at 850 and 800, 1700 at 800. The hashrate does not move
with voltage; only power and heat do. The default curve now tops out at 900 mV (50 mV above
the last point that held) instead of 1000. `--bc250-gpu-mv` overrides it, and **going
below ~850 mV at 2000 MHz is a hang on the board tested**.

---

## Quantus on the BC-250 (2026-10-01)

Correct and working: all 67,584 full 512-bit digests match the pinned Rust reference on
gfx1013, the stage2 affine search gate passes (444 checks, 111 launches, 16,662 strict winners
inside 16,752 prefix candidates), and on the live lproute pool **9 shares were accepted and 0
rejected in 11.5 minutes**.

Rate with all 40 CUs, 2000 MHz, 900 mV: **115.3 MH/s displayed** (pool-measured 130 MH/s over
that window, 9 shares so noisy), 118 W, 77 C. The kernel harness
(`docs/benchmarks/pearl-bc250-20260930/qbench.py`) gives 87.4 MH/s at the stock 1500 MHz, which
scales to the miner's figure, so the host path loses nothing. Launch geometry is flat:
workgroup size 32/64/128/256 all within 0.2%, and batch 1M/4M/16M is 85.6/87.4/87.8.

Where the time goes (`micro2.cl`, measured here): `v_mad_u64_u32`, `v_mul_lo_u32` and
`v_mul_hi_u32` issue at 0.90 T/s, a quarter of the 3.1-3.4 T/s of carry adds and 24-bit
multiplies. The kernel has ~994 `v_mad_u64_u32` and ~7,000 carry-chain adds per hash, so the
quarter-rate multiplies are about a third of the cost. Rebuilding the 64x64 product from
full-rate 24-bit multiplies needs 18 multiplies plus more carry work than it saves, so there is
no cheap win left here; the kernel is already the RDNA2 lean-field design.

SRBMiner 3.6.9 cannot mine Quantus on this board (`couldn't setup ctx->algorithm`).

---

## CryptoNight (cn/gpu) and Cuckaroo29 (c29) on the BC-250 (2026-10-01)

Both work and are valid on a live pool, 40 CUs, 2000 MHz / 900 mV, as shipped:

| | rate | power | live shares |
|---|---:|---:|---|
| cn/gpu (MoneroOcean, `--pass x~cn/gpu`) | 1.86 kH/s | 130 W, 82 C | 12 accepted, 0 rejected |
| c29 (Kryptex `xtm-c29-us`, any username login) | 4.75 graphs/s | ~100 W, 71 C | 5 accepted, 0 rejected |

Logins that do not work today: MoneroOcean serves RandomX unless the password pins
`~cn/gpu` (the cn plugin ignores those jobs and sits at 0 H/s), MoneroOcean has no c29
template right now ("No block template yet"), and Kryptex refuses a Monero address
("Invalid login") but takes a plain username.

SRBMiner 3.6.9 (with a pty and `--bc250`) cannot mine either competitor-comparable work here:
cryptonight_gpu stayed at 0.00 H/s and ~49 W (idle) for ~9 minutes after autotune, and it has no
Cuckaroo29. So there is no competitor figure for these two on this board.

cn/gpu headroom: hashes in flight saturate by ~2000 (1024 -> 1.62, 2048 -> 1.83, 3008 -> 1.86
kH/s), so occupancy is not the limit. The loop kernel is ~2,400 VALU per lane per iteration
(float adds/muls, 400 mask ops, 16 correctly rounded divides), which at 16 lanes and 49,152
iterations per hash puts the FP32 ceiling near 2.7 kH/s at 2000 MHz; the kernel reaches ~69%
of that. It uses 248 VGPRs and 132 bytes of scratch (occupancy 4), and has two LDS barriers
and a global fence per iteration. The kernel is one generic `cn.cl` for every GPU, with the
work-group size fixed at 64 by the host, so a per-architecture version is where a gain would
come from. c29 has not been profiled on this board.

<!-- pwn -->
