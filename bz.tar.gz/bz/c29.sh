#!/usr/bin/env bash
# bz v100.60 - sample c29 launcher
#
# Tari Tari original Cuckaroo29 (C29/CR29), experimental NVIDIA CUDA mining
# with an automatic RTX 3090 profile, plus experimental Intel Arc Battlemage
# (B570/B580/Pro B-series) and AMD OpenCL. Every 42-edge proof is checked by
# the portable Tari consensus reference before submission. Monero wallet at
# MoneroOcean; Tari wallet at a direct XTM-C29 pool.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# One line per coin. The FIRST is live; to mine a different coin,
# comment this one out and uncomment that one.
#
# -a picks the chain, so it changes with the pool - and so does the
# wallet, since every coin has its own address format.
# Coins: `c29`.

# --- MoneroOcean (Tari C29, paid in XMR) (c29)
#   C29-pinned login; current artifact 8F3593B8...E023 had three fee shares accepted through bzproxy with zero rejects on 2026-09-05
./b --config c.txt -a c29 -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass rig1~c29 --worker rig1

# --- Tari (c29)
#   One live bz share accepted with zero rejects on 2026-09-04;
#   functional validation only
# ./b --config c.txt -a c29 -p stratum+tcp://taric29.luckypool.io:3111 -w YOUR_TARI_WALLET_HERE --pass x --worker rig1
#   Preserved artifact 5C01EE2E...FE46: one live share accepted with zero
#   rejects in the 180-second revalidation on 2026-09-05
# ./b --config c.txt -a c29 -p stratum+tcp://xtm-c29-us.kryptex.network:7040 -w YOUR_TARI_WALLET_HERE --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
