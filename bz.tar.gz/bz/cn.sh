#!/usr/bin/env bash
# bz v100.60 - sample cn launcher
#
# CryptoNight The CryptoNight family on NVIDIA CUDA, AMD/Intel OpenCL, Apple
# Metal and the CPU: cn/gpu (Conceal, Ryo - the variant the live chains run)
# plus the eighteen classic variants cn/0, cn/1, cn/2, cn/fast, cn/half,
# cn/xao, cn/rto, cn/rwz, cn/zls, cn/double, cn/ccx, cn-lite/0, cn-lite/1,
# cn-heavy/0, cn-heavy/xhv, cn-pico, cn-pico/tlo and cn/upx2 - on NVIDIA one
# kernel, one cubin per architecture from Pascal (GTX 10xx) to Blackwell; on
# AMD and Intel the same six kernels in OpenCL, offline-compiled to SPIR-V
# plus a native object per GCN/RDNA architecture; on the CPU a kernel per
# instruction set (AES-NI, AVX2, AVX-512) chosen at run time, so one build
# serves Zen 1 through Zen 5, EPYC and Intel. `-a cn` lets an auto-switching
# pool (MoneroOcean) choose the variant per job; naming one mines that
# variant. No CUDA toolkit is required on the rig. The wallet address of the
# coin being mined - a Monero address at MoneroOcean, whatever the variant.
# The worker name is a separate --worker argument, not a suffix on the
# address.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# One line per coin. The FIRST is live; to mine a different coin,
# comment this one out and uncomment that one.
#
# -a picks the chain, so it changes with the pool - and so does the
# wallet, since every coin has its own address format.
# Coins: `cn`, `cn/gpu`.

# --- MoneroOcean (CryptoNight, paid in XMR) (cn)
#   MoneroOcean (TLS) - the ~cn/gpu pin in the password is REQUIRED; without it the login is refused with 'No block template yet. Please wait.' (re-checked 2026-09-04)
./b --config c.txt -a cn -p stratum+ssl://gulf.moneroocean.stream:20128 -w 4YOUR_MONERO_WALLET_HERE --pass rig1~cn/gpu --worker rig1
#   MoneroOcean (plain) - same, the ~cn/gpu pin is required (re-checked
#   2026-09-04)
# ./b --config c.txt -a cn -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass rig1~cn/gpu --worker rig1

# --- Conceal (cn/gpu)
#   Conceal's community pool - answers logins (validates the address)
# ./b --config c.txt -a cn/gpu -p stratum+tcp://pool.conceal.network:3333 -w ccx7YOUR_CONCEAL_WALLET_HERE --pass x --worker rig1
#   GNTL
# ./b --config c.txt -a cn/gpu -p stratum+tcp://ccx.pool.gntl.co.uk:3333 -w ccx7YOUR_CONCEAL_WALLET_HERE --pass x --worker rig1
#   Cedric Crispin (TLS) - answers logins; 3364 plain
# ./b --config c.txt -a cn/gpu -p stratum+ssl://conceal.cedric-crispin.com:3365 -w ccx7YOUR_CONCEAL_WALLET_HERE --pass x --worker rig1

# --- Ryo (cn/gpu)
#   MoneroOcean - add ~cn/gpu to the password to pin; pays in XMR
# ./b --config c.txt -a cn/gpu -p stratum+tcp://gulf.moneroocean.stream:10128 -w 4YOUR_MONERO_WALLET_HERE --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
