#!/usr/bin/env bash
# bz v100.60 - sample verus launcher
#
# VERUS VerusHash v2.2 CPU mining. A Verus R-address. The worker name is a
# separate --worker argument, not a suffix on the address.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

./b --config c.txt -a verus -p stratum+ssl://bzdev.vipor.net:5140 -w YOUR_VERUS_WALLET --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
