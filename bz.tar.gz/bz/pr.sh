#!/usr/bin/env bash
# bz v100.60 - sample pearl launcher
#
# Pearl a zk proof-of-work: each share is a STARK proof, so it is far
# heavier per hash than a normal algorithm. Also mines SOLO - point -p at
# your node's RPC URL instead of a pool. Wallet addresses start with 'prl1'.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# The first line is live. To use a different pool, comment it out
# and uncomment one below.

./b --config c.txt -a pearl -p stratum+tcp://us.pearl.herominers.com:1200 -w prl1YOUR_PEARL_WALLET_HERE --pass x --worker rig1

#   Kryptex
# ./b --config c.txt -a pearl -p stratum+tcp://prl-us.kryptex.network:7048 -w prl1YOUR_PEARL_WALLET_HERE --pass x --worker rig1
#   LuckyPool (EU, CPU pool)
# ./b --config c.txt -a pearl -p stratum+tcp://pearl-cpu-eu1.luckypool.io:3370 -w prl1YOUR_PEARL_WALLET_HERE --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
