#!/usr/bin/env bash
# bz v100.60 - sample randomx launcher
#
# Monero, Zephyr, Salvium RandomX (rx/0) on NVIDIA CUDA, AMD OpenCL and the
# CPU: Monero, plus Zephyr and Salvium, which run it unmodified. Written
# from the specification rather than vendored. On the CPU the virtual
# machine is compiled at run time, with code generator tiers for BMI2,
# AVX-512 and VAES. On a GPU the same program runs eight threads to a hash
# against a schedule built once per program, one cubin per NVIDIA
# architecture from Pascal to Blackwell and a native object per AMD
# architecture from Vega through RDNA 4. No CUDA toolkit is required on the
# rig. A Monero address. The worker name is a separate --worker argument,
# not a suffix on the address.
#
# EDIT THE WALLET BELOW before running - it is a placeholder, not a real
# address, and the pool will reject shares sent to it.

cd "$(dirname "$0")" || exit 1

# The first line is live. To use a different pool, comment it out
# and uncomment one below.

./b --config c.txt -a randomx -p stratum+ssl://gulf.moneroocean.stream:20128 -w YOUR_MONERO_WALLET --pass x --worker rig1

#   MoneroOcean (plain)
# ./b --config c.txt -a randomx -p stratum+tcp://gulf.moneroocean.stream:10128 -w YOUR_MONERO_WALLET --pass x --worker rig1
#   SupportXMR (TLS)
# ./b --config c.txt -a randomx -p stratum+ssl://pool.supportxmr.com:9000 -w YOUR_MONERO_WALLET --pass x --worker rig1
#   SupportXMR (plain)
# ./b --config c.txt -a randomx -p stratum+tcp://pool.supportxmr.com:3333 -w YOUR_MONERO_WALLET --pass x --worker rig1
#   HeroMiners
# ./b --config c.txt -a randomx -p stratum+tcp://monero.herominers.com:1111 -w YOUR_MONERO_WALLET --pass x --worker rig1
#   HashVault
# ./b --config c.txt -a randomx -p stratum+tcp://pool.hashvault.pro:3333 -w YOUR_MONERO_WALLET --pass x --worker rig1

# Add any of these to the end of the line you are running:
#   --nvidia                 mine only on NVIDIA (also --amd/--intel/--cpu)
#   --oc-power-limit 160     see d.txt for the rest of the --oc-* options
#   --benchmark              ignore the pool and mine a local test server

# pwn
