#!/bin/sh
./s --list-devices

# pwn
