#!/bin/sh
./s --setup

# pwn
