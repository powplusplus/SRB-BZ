#!/bin/sh
./s --list-algorithms

# pwn
