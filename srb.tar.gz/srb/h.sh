#!/bin/sh
./s --help

# pwn
